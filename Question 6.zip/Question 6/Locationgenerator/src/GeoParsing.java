/**
 * Created by vt on 4/3/16.
 */
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.geo.topic.GeoParser;
import org.apache.tika.parser.geo.topic.GeoParserConfig;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;

import java.io.*;


public class GeoParsing {

    public String getLocationDetails(File document) throws  TikaException, IOException, SAXException
    {
        String text;
        Parser parser = new AutoDetectParser();
        BodyContentHandler handler = new BodyContentHandler();
        Metadata metadata = new Metadata();

        try {
            parser.parse(TikaInputStream.get(document), handler, metadata, new ParseContext());
        }

        catch (Exception e){
            throw new RuntimeException(e);
        }
        text = handler.toString();

        Parser objGeoParser = new GeoParser();
        ParseContext objContextParser = new ParseContext();
        metadata = new Metadata();
        GeoParserConfig objConfig = new GeoParserConfig();
        objContextParser.set(GeoParserConfig.class, objConfig);
        InputStream contentstream = new ByteArrayInputStream(text.getBytes());
        objGeoParser.parse(contentstream, new BodyContentHandler(), metadata, objContextParser);

         return  metadata.get("Geographic_NAME")+","+metadata.get("Geographic_LATITUDE")+","+metadata.get("Geographic_LONGITUDE");



    }
}
