import org.apache.tika.exception.TikaException;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class locationgenerator {

    public static void main(String args[]) throws IOException, TikaException, SAXException {

        GeoParsing objGeoParser = new GeoParsing();


        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the directory name");
        String dirName = sc.next();
        if (dirName.length() == 0) {
            System.out.println("Please enter a valid directory name");

        } else {
            FileWriter objFile = new FileWriter(dirName + "/" + "output.csv");
            objFile.close();
            File tempFile = new File(dirName);
            if (tempFile.isDirectory()) {
                File[] fileArray = tempFile.listFiles();
                for (File eachFile : fileArray) {
                    if (objGeoParser.getLocationDetails(eachFile).length() != 0) {
                        objFile.write(objGeoParser.getLocationDetails(eachFile) + "\n");
                    }
                    ;


                }
            } else {
                objFile.write(objGeoParser.getLocationDetails(tempFile) + "\n");
                objFile.close();
            }


        }
    }
}