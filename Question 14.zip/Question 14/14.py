import os
import sys
import json
arg1=str(sys.argv[1])
for root, dirs, files in os.walk(arg1):
    for file in files:
        if(file!='.DS_Store'):
            path=os.path.join(root,file)
            command='curl -T'+path+'-H "Content-Disposition: attachment;filename='+path+'" http://localhost:9998/rmeta'
            p=os.popen(command).read()
            output=os.popen('p | python -mjson.tool')
            with open("exif.json",'a+') as f:
                json.dumps(output,f)






