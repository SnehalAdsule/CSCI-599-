import json
import simplejson
import os

with open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/Quality/MetaQualityScore_2.json', 'rb') as data_file:
    my_data = data_file.read()
newJSON=json.loads(my_data)
print newJSON
count=1
output="C:/Users/Snehal/Documents/tikaSimilarityTestSet"
for j in newJSON:
   str1=json.dump(j)
   str2="{'id':'"+str(count)+"','data':["+str1+"]}"
   print count,"  Name =", str2
   curl_cmd = 'curl "http://localhost:8983/solr/gettingstarted/update/json/docs"' \
              ' -d "'+str2+'>'+output+'/text.out'
   os.popen(curl_cmd)
   print curl_cmd
   if count>=1:
    break
   count+=1
