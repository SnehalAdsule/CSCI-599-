from urllib2 import *
import simplejson
import json
from io import StringIO, BytesIO
from lxml import etree

# Print the name of each document.
def getIndex():
    connection = urlopen('http://localhost:8983/solr/gettingstarted/select?q=*:*&wt=json')
    response = simplejson.load(connection)

    print response['response']['numFound'], "documents found."
    f = open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/index.json', 'w')
    json.dump(response, f)
    f.close()
   # for j in response['response']['docs']:
    #  print "  Name =", j
    return

def getSchema():
    connection = urlopen('http://localhost:8983/solr/gettingstarted/schema?wt=schema.xml')
    f = open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/Schema.xml', 'w')
    response = connection.read()
    f.write(response)
    f.close()
   # for j in response['response']['docs']:
    #  print "  Name =", j
    return

def defineScema():
    connection = urlopen('http://localhost:8983/solr/gettingstarted/schema?wt=schema.xml')
    f = open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/Schema.xml', 'w')
    response = connection.read()
    f.write(response)
    f.close()
   # for j in response['response']['docs']:
    #  print "  Name =", j
    return

def deleteIndex():
    connection = urlopen('http://localhost:8983/solr/update?q=<delete><query>*:*</query></delete>')
    f = open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/deleteIndex.txt', 'w')
    response = connection.read()
    f.write(response)
    f.close()
    return

def addData():
    connection = urlopen('http://localhost:8983/solr/gettingstarted/update?q=<delete><query>*:*</query></delete>')
    f = open('C:/Users/Snehal/Documents/tikaSimilarityTestSet/deleteIndex.txt', 'w')
    response = connection.read()
    f.write(response)
    f.close()
    return

if __name__ == "__main__":

 #deleteIndex()
   getIndex()
   getSchema()

