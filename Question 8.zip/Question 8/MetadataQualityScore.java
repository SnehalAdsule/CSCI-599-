/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.usc.polar;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.xml.sax.SAXException;

/**
 *
 * @author Sneh
 */
public class MetadataQualityScore {

    public static int counter = 0;
    public static long jsonCount = 0;
    public static FileWriter jsonFile;
    public static File file;
    public static JSONArray jsonArray = new JSONArray();

    public static void main(String args[]) {
                        dir("C:\\Users\\Snehal\\Documents\\TREC-Data\\Data");
                        try{
                        if(jsonFile!=null)
                           {jsonFile.write(jsonArray.toJSONString());
                           // System.out.println(jsonArray.toJSONString());
                           jsonFile.close();
                           }  
                        }catch(Exception e){
                        e.printStackTrace();}

    }

    public static double MetaScore(Metadata met) {
        double score = 0;
        double dublinScore = 0;
        double dublinWt = 0.4;
        double descMetaScore = 0;
        double descWt = 0.1;
        double structScore = 0;
        double structWt = 0.1;
        double quantityScore = 0;
        double countWt = 0.1;
        double rightScore = 0;
        double rightWt = 0.1;
        double DOIScore = 0;
        double DoIWeight = 0.1;
        double preservationScore = 0;
        double presWt = 0.1;

//score on dublin core std
        String dublin[] = {"TITLE", "CREATOR", "AUTHOR", "SUBJECT",
            "DESCRIPTION", "PUBLISHER", "CONTRIBUTOR", "DATE", "TYPE", "FORMAT", "IDENTIFIER", "SOURCE", "LANGUAGE", "RELATION",
            "COVERAGE", "RIGHTS"};

// Description field ,title, and version
        String descMetadata[] = {"TITLE", "CREATOR", "AUTHOR", "SUBJECT",
            "DESCRIPTION", "TYPE", "CONTRIBUTOR", "NAME", "SOURCE", "<META>", "KEYWORDS"};

//naming conflicts / ALIAS
        String DOIMetadata[] = {"NAME", "ALIAS", "ALT", "RESOURCES", "ENCODING", "TYPE", "URI", "FORMAT", "IDENTIFIER", "ID", "URL", "LANGUAGE", "MESSAGE"};

//
        String structMetadata[] = {"PAGE", "SECTION", "INDEX", "URL", "LENGTH", "TABLE OF CONTENT", "PART", "REFERENCES", "INSTITUTION", "ALTTEXT", "TEXT",
            "COMPANY", "CATEGORY", "CONTACT", "PROGRAM", "PROJECT", "CONVENTIONS", "CONTACT", "MODEL", "ALIAS", "REF"};

        String rightMgmtMetaData[] = {"COVERAGE", "RIGHTS", "CONTRIBUTOR", "PUBLISHER", "LICENSE", "ACKNOWLEDGEMENT", "SECURITY", "MANAGER", "SOFTWARE", "CREDITS"};

// long term 
        String preserveMetadata[] = {"VERSION", "REVISION", "COUNT", "INDEX", "NOTES", "EDIT_TIME",
            "CONTENT_STATUS", "CREATION_DATE", "EDIT_TIME", "IMAGE_COUNT", "COMMENT", "USER_DEFINED_METADATA", "ORIGINAL_DATE",
            "TIME", "HISTORY", "LAST_", "ARCHIVE"};

        String mList[] = met.names();
        int size = met.size();
        for (int i = 0; i < met.size(); i++) {
//System.out.println(mList[i].toString().toUpperCase());

            //DUBLIN score
            for (String type : dublin) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    dublinScore++;
                }
            }

            //desc
            for (String type : descMetadata) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    descMetaScore++;
                }
            }

            //DOI
            for (String type : DOIMetadata) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    DOIScore++;
                }
            }

            //Structural
            for (String type : structMetadata) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    structScore++;
                }
            }

            //Quantity
            quantityScore = 1;
            //right
            for (String type : preserveMetadata) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    preservationScore++;
                }
            }

            //right
            for (String type : rightMgmtMetaData) {
                if (mList[i].toString().toUpperCase().contains(type)) {
                    rightScore++;
                }
            }

        }
        dublinScore = (double) (dublinScore / size);
        DOIScore = (DOIScore / size);
        descMetaScore = (descMetaScore / size);
        structScore = (structScore / size);
        preservationScore = (preservationScore / size);
        rightScore = (rightScore / size);

//System.out.println("Size:"+size+"Dublin:"+dublinScore +"Desc"+descMetaScore+ "DOI"+DOIScore+"Struct"  + structScore + "Preserve"+preservationScore + "right:"+rightWt*rightScore);
        score = dublinWt * dublinScore + descWt * descMetaScore + DoIWeight * DOIScore
                + structWt * structScore + presWt * preservationScore + rightWt * rightScore + countWt * quantityScore;
        return score;

    }

    public static Metadata getMetURL(URL url) throws IOException, SAXException,
            TikaException {
        Metadata met = new Metadata();
        PDFParser parser = new PDFParser();
        parser.parse(url.openStream(), new BodyContentHandler(), met, new ParseContext());
        return met;
    }

    public static Metadata getMet(String file) throws IOException, SAXException,
            TikaException {
        InputStream stream = new FileInputStream(file);
        Metadata met = new Metadata();
        AutoDetectParser parser = new AutoDetectParser();
        parser.parse(stream, new BodyContentHandler(), met, new ParseContext());
        return met;
    }

    public static void dir(String path) {
        try {

            File root = new File(path);
            if (root.isFile()) {

                if (counter >= 1000 || file == null) {
                    counter = 0;
                    jsonCount++;
                    file = new File("C:\\Users\\Snehal\\Documents\\tikaSimilarityTestSet\\Quality\\MetaQualityScore_" + jsonCount + ".json");
                    jsonFile = new FileWriter(file);
                    jsonArray = new JSONArray();
                }

                if (!root.getName().equals((".DS_Store"))) {
                    Metadata met = getMet(root.getAbsolutePath());
                    // System.out.println(met.size());
                    double score = MetaScore(met);
                    // System.out.println( "[{\"DOI\":\""    + root.getPath().replace("C:\\Users\\Snehal\\Documents\\TREC-Data\\Data\\","")+"\"},{\"score\":"+score+"}]");
                }
            } else {
                File[] list = root.listFiles();
                if (list == null) {
                    return;
                }
                for (File f : list) {
                    if (f.isDirectory()) {
                        dir(f.getAbsolutePath());
                        // System.out.println( "Dir:" + f.getAbsoluteFile() );
                    } else {
                        if (counter >= 1000||file==null) {
                            counter = 0;
                            jsonCount++;
                            file = new File("C:\\Users\\Snehal\\Documents\\tikaSimilarityTestSet\\Quality\\MetaQualityScore_" + jsonCount + ".json");
                          // System.out.print("check"+jsonArray.toJSONString());
                            if(jsonFile!=null)
                           {jsonFile.write(jsonArray.toJSONString());
                            //System.out.println(jsonArray.toJSONString());
                           jsonFile.close();
                           }                           
                            jsonFile = new FileWriter(file);
                            jsonArray = new JSONArray();
                        }

                        if (!f.getName().equals((".DS_Store"))) {
                            Metadata met = getMet(f.getAbsolutePath());
                            // System.out.println(met.size());
                            double score = MetaScore(met);
                            counter++;
                            JSONObject jsonObj = new JSONObject();
                            jsonObj.put("DOI", f.getPath().replace("C:\\Users\\Snehal\\Documents\\TREC-Data\\Data\\", ""));
                            jsonObj.put("Score", score);
                            jsonArray.add(jsonObj);
                          /*  System.out.println(counter 
                                    + "[{\"DOI\":\"" + f.getPath().replace("C:\\Users\\Snehal\\Documents\\TREC-Data\\Data\\", 
                                            "") + "\"},{\"score\":" + score + "}]"
                            );*/
                           
                            //jsonWrite(file, f.getPath().replace("C:\\Users\\Snehal\\Documents\\TREC-Data\\Data\\", ""),   score + ""                            );
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.toString();

        }
    }

    public static void jsonWrite(File file, String DOI, String score) throws IOException {

        JSONObject jsonObj = new JSONObject();
        jsonObj.put("DOI", DOI);
        jsonObj.put("Score", score);
        jsonArray.add(jsonObj);

    }

}
