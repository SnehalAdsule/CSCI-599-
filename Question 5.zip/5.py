import os
import re
import tika
import time
from tika import parser
grobid_home='/Users/anirbanmishra/src/grobid'
grobid_snapshot_dir=grobid_home+'/grobid-core/target/grobid-core-0.4.1-SNAPSHOT.one-jar.jar'
grobig_prop= grobid_home+'/grobid-home/config/grobid.properties'
grobid_home_dir=grobid_home+'/grobid-home/'
pdf_input='/Users/anirbanmishra/Downloads/Contents/pdf/training/'
output_pdf='/Users/anirbanmishra/src/grobid/output_pdf/'
output=grobid_home+'/out/'
work_related='/Users/anirbanmishra/src/grobid/work_related'
count=0
for root, dirs, files in os.walk(pdf_input):
    for file in files:
        if(file!='.DS_Store'):
            path=os.path.join(root,file)
            tika.initVM()
            with open(path,'r') as f:
                parsed = parser.from_file(path)
                content=parsed.get("content")
                count+=1
                print count
                if(content!=None):
                    filename=output+'/'+file+'.tei.xml'
                    if os.path.exists(filename):
                        os.remove(filename)
                    p=os.popen('curl -v -include --form input=@'+path+' '+'localhost:8080/processFulltextDocument'+'>>'+' '+output+'/'+file+'.tei.xml').read()
root_dir=output
first=''
middle=''
last=''
for root, dirs, files in os.walk(root_dir):
    for file in files:
        if(file.endswith(".xml")):
            path=os.path.join(root,file)
            with open(path,'r') as f:
                for line in f:
                    if(line.__contains__('<forename type="first">')):
                        first=line
                    elif(line.__contains__('<forename type="middle">')):
                        middle=line
                    elif(line.__contains__('<surname>')):
                        last=line
                        break
            first=re.sub('<[^<]+?>','', first)
            middle=re.sub('<[^<]+?>','', middle)
            last=re.sub('<[^<]+?>','', last)
            first=first.strip()
            middle=middle.strip()
            last=last.strip()
            name=first+' '+middle+' '+last
            name=name.strip()
            first=''
            middle=''
            last=''
            google_api='/Users/anirbanmishra/Downloads/scholar.py-master/'
            if(len(name)>0):
                process='python'+' '+google_api+'scholar.py --txt-globals --author'+' '+'"'+name+'"'+'>>'+' '+work_related+'/'+name+'.txt'
                a=os.popen(process).read()
            time.sleep(5)


