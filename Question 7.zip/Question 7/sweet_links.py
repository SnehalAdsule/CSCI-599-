import os
import sys
arg1=str(sys.argv[1])
for root, dirs, files in os.walk(arg1):
    for file in files:
        filename= os.path.splitext(os.path.basename(file))[0]
        if(file.__contains__('.owl')):
            path=os.path.join(root,file)
            with open(path,'rb') as f:
                for line in f:
                    line=line.strip()
                    if(line.__contains__("rdf:resource")):
                        line=line.split('=')[1]
                        line=line[1:]
                        line=line.split('"')[0]
                        with open ("sweet_links.txt",'a+') as f:
                            f.write(line+'\n')

