import urllib2
import re
import os
import sys
sys.setrecursionlimit(1000000)
count=0
content1=''
content2=''
def preprocess(lines):
    links=''
    response = urllib2.urlopen(lines)
    html = response.read().splitlines()
    for line in html:
        if(line.__contains__("!ENTITY")):
            line=line.strip(' ')
            line=line.split(' ')
            print line
            name=line[1]
            link=re.sub('">','',line[2])
            link=re.sub('"h','h',link)
            if('&' in link):
                link=link.split(';')
                word=link[0]
                word=word[2:]
                with open("common_links.txt",'r') as fopen:
                    for lines in fopen:
                        if lines.__contains__(word):
                            lines=lines.split(' ')[1]
                            lines=lines.strip('\n')
                            link=lines+link[1]
                            break
            with open("common_links.txt",'a+') as fopen:
                fopen.write(name+' '+link+'\n')
def process(line,filename,links_file):
    line=line.strip()
    response = urllib2.urlopen(line)
    html = response.read().splitlines()
    with open(filename, 'a+') as a, open(links_file, 'r+') as b:
        for line in html:
            if(line.__contains__("rdf:about")):
                if(line.__contains__('owl:versionInfo')==False):
                    line=line.split('=')
                    word=line[1]
                    word=word[2:]
                    word=word.split('"')[0]
                    a.write(word+' ')
            if(line.__contains__("rdf:resource")):
                if((('&' in line) and ('#') in line)==False):
                    line=line.split('=')
                    word=line[1]
                    word=word[2:]
                    word=word.split('"')[0]
                    a.write(word+' ')
                elif((('&' in line) and ('#') in line)):
                    line=line.split('=')[1]
                    line=line.split(';')
                    link=line[0]
                    ext=line[1]
                    ext=ext.split('"')[0]
                    link=link[2:]
                    with open("common_links.txt",'r') as fopen:
                        for lines in fopen:
                            if lines.__contains__(link):
                                lines=lines.split(' ')[1]
                                lines=lines.strip('\n')
                                links=lines+ext
                                if os.stat(links_file).st_size > 0:
                                    for l in b:
                                        if(l.__eq__(links)==False):
                                            b.write(links+'\n')
                                            preprocess(links)
                                            process(links,filename,links_file)
                                        else:
                                            continue
                                else:
                                    b.write(links+'\n')
                                    preprocess(links)
                                    process(links,filename,links_file)

with open("sweet_links.txt",'r') as fopen:
    for line in fopen:
        count+=1
        if(count<=1):
            line='http://sweet.jpl.nasa.gov/2.3/humanJurisdiction.owl'
            filename=os.path.basename(os.path.normpath(line))
            filename=re.sub('.owl','.txt',filename)
            links_file="links_"+filename
            preprocess(line)
            process(line,filename,links_file)
            content1=''
            content2=''