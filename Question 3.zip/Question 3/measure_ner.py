import os
import re
import sys
import json
arg1=str(sys.argv[1])
content=''
measurements={'degree','celsius','c','farenheit','f','kelvin','k','mm','milimeters','cm','centimeters','km','kilometers','mile','inch','inches','meter','metre','foot','feet','litre','gallon','pound','l','ml','minute','second','millisecond','hour','day','year','month','week','kilograms','kg','miligrams','mg','tons','g','grams'}
category={'temperature','length','time','volume','weight'}
temperature={'degree','celsius','c','farenheit','f','kelvin','k'}
length={'mm','milimeters','cm','centimeters','km','kilometers','mile','inch','inches','meter','metre','foot','feet'}
time={'minute','second','millisecond','hour','day','year','month','week',}
volume={'litre','gallon','pound','l','ml'}
weight={'kilograms','kg','miligrams','mg','tons','g','grams'}
data=''
value=''
unit=''
category=''
stop_words={'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', "arent", 'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', "cant", 'cannot', 'could', "couldnt", 'did', "didnt", 'do', 'does', "doesnt", 'doing', "dont", 'down', 'during', 'each', 'few', 'for', 'from', 'further', 'had', "hadnt", 'has', "hasnt", 'have', "havent", 'having', 'he', "hed", "hes", 'her', 'here', "heres", 'hers', 'herself', 'him', 'himself', 'his', 'how', "hows", 'i', "id", "im", "ive", 'if', 'in', 'into', 'is', "isnt", 'it', "its", 'its', 'itself', "lets", 'me', 'more', 'most', "mustnt", 'my', 'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', "shant", 'she', "shed", "shes", 'should', "shouldnt", 'so', 'some', 'such', 'than', 'that', "thats", 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', "theres", 'these', 'they', "theyd", "theyll", "theyre", "theyve", 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', "wasnt", 'we', "we'd", "well", "were", "weve", 'were', "werent", 'what', "whats", 'when', "whens", 'where', "wheres", 'which', 'while', 'who', "whos", 'whom', 'why', "whys", 'with', "wont", 'would', "wouldnt", 'you', "youd", "youll", "youre", "youve", 'your', 'yours', 'yourself', 'yourselves'}
count=0
json_count=1
measurement_count=0
file_count=0
def printToFile(filename,value,unit,category,measure_count,f_count):
    if(f_count>1000):
        global file_count
        file_count=1
        global json_count
        json_count+=1
        f_count=1
    file="measurement"+str(json_count)+".json"
    value=value.strip().split(' ')
    unit=unit.strip().split(' ')
    category=category.strip().split(' ')
    if (f_count==1):
        with open(file,'a+') as f:
            f.write("{"+'"'+filename+'"'+' '+':[')
            for i in range(0,len(value)):
                f.write('{'+'"value"'+' '+':'+' '+'"'+value[i]+'",')
                f.write('"unit"'+' '+':'+' '+'"'+unit[i]+'",')
                f.write('"category"'+' '+':'+' '+'"'+category[i]+'"},')
            f.seek(-1, os.SEEK_END)
            f.truncate()
            f.write(']')
    elif(f_count>1):
        with open(file,'a+') as f:
            f.write(","+'"'+filename+'"'+' '+':[')
            for i in range(0,len(value)):
                f.write('{'+'"value"'+' '+':'+' '+'"'+value[i]+'",')
                f.write('"unit"'+' '+':'+' '+'"'+unit[i]+'",')
                f.write('"category"'+' '+':'+' '+'"'+category[i]+'"},')
            f.seek(-1, os.SEEK_END)
            f.truncate()
            f.write(']')


for root, dirs, files in os.walk(arg1):
    for file in files:
        flag=False
        if(file!='.DS_Store'):
            path=os.path.join(root,file)
            filename= os.path.splitext(os.path.basename(file))[0]
            flag1=True
            with open(path,'r') as f:
                for line in f:
                    line=line.strip().lower()
                    line=line.split(' ')
                    for word in line:
                        if (len(word)>0 and word not in stop_words):
                            if(measurements.__contains__(word)):
                                pos=line.index(word)
                                if(line[pos-1].isdigit()):
                                    unit+=word+' '
                                    if(flag1):
                                        global file_count
                                        file_count+=1
                                        flag1=False
                                        print file+' '+str(file_count)
                                if(line[pos-1].isdigit()):
                                    if(temperature.__contains__(word)):
                                        category+='temperature'+' '
                                    if(length.__contains__(word)):
                                        category+='length'+' '
                                    if(time.__contains__(word)):
                                        category+='time'+' '
                                    if(volume.__contains__(word)):
                                        category+='volume'+' '
                                    if(weight.__contains__(word)):
                                        category+='weight'+' '
                                if(line[pos-1].isdigit()):
                                    value+=str(line[pos-1])+' '
                    if(len(value)>0 and len(unit)>0 and len(category)>0)  :
                        flag=True
            if(flag):
                printToFile(filename,value,unit,category,-1,file_count)
                value=''
                unit=''
                category=''

for root, dirs, files in os.walk('/Users/anirbanmishra/PycharmProjects/Ner/'):
    for file in files:
        if(file.__contains__(".json")):
            with open(file, 'a+') as filehandle:
                #filehandle.seek(-1, os.SEEK_END)
                #filehandle.truncate()
                filehandle.write('}')