
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.ToXMLContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

 class ContentHandlerExample {
    public static String parseToHTML(String filename) throws IOException, SAXException, TikaException {
        ContentHandler handler = new ToXMLContentHandler();

        AutoDetectParser parser = new AutoDetectParser();
        Metadata metadata = new Metadata();
        try (InputStream stream = ContentHandlerExample.class.getResourceAsStream(filename)) {
        	if(stream==null)
        	{
        		return null;
        	}
        	else{
            parser.parse(stream, handler, metadata);
            return handler.toString();}
        }
    }
}
 public class measure{
	 public static void walk( String path ) throws IOException, SAXException, TikaException {

	        File root = new File( path );
	        File[] list = root.listFiles();

	        if (list == null) return;

	        for ( File file : list ) {
	            if ( file.isDirectory() ) {
	                walk( file.getAbsolutePath() );
	            }
	            else {
	            	if(file.getName().toString().equals(".DS_Store"))
	            		continue;
	            	Path paths=Paths.get(file.getCanonicalPath());
	            	moveToFolder(paths);
	    	        String filename=file.getName().toString();
	    	        String name="/Users/anirbanmishra/Downloads/measurements_files/"+filename+".txt";
	    	   		 PrintWriter writer = new PrintWriter(name, "UTF-8");
	    		 String html_content=ContentHandlerExample.parseToHTML(filename);
	    		 if(html_content!=null){
	    		 Scanner scanner = new Scanner(html_content);
	    		 boolean flag1=false;
	    		 boolean flag2=false;
	    		 while (scanner.hasNextLine()) {
	    		   String line = scanner.nextLine();
	    		   if(line.contains("<body>"))
	    			   flag1=true;
	    		   if(line.contains("</body>"))
	    			   flag2=true;
	    		   if(flag1 && !flag2){
	    			   line=line.replaceAll("\\<[^>]*>","");			   
	    			   writer.println(line);			   
	    		   }
	    		   }
	    		 }
	    		 Path del=Paths.get("/Users/anirbanmishra/Documents/workspace/Assignment2/src/"+filename);
	    		 Files.delete(del);
	    		 writer.close();
	    	        
	            }
	        }
	        }
		    public static void moveToFolder(Path source) throws IOException{
		    	String filename=source.getFileName().toString();
		        String dest="/Users/anirbanmishra/Documents/workspace/Assignment2/src/"+filename;
		        Path destination=Paths.get(dest);
		        boolean pathExists =true;
		        if(pathExists)
		        {
		        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
		        }
		    }
	 public static void main(String args[]) throws IOException, SAXException, TikaException{
		 File dir = new File("/Users/anirbanmishra/Downloads/Data/");
	        File[] filesList = dir.listFiles();
	        for (File file : filesList) {
	        	walk(file.toString());
	        }
 }
 }
 